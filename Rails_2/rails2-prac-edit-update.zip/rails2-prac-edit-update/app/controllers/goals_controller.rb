class GoalsController < ApplicationController

    before_action :require_signed_in!

    def create
        # debugger
        @goal = Goal.new(goal_params)
        @goal.user_id = params[:user_id]

        if @goal.save
        else
            flash[:errors] = @goal.errors.full_messages
        end

        #  we are redirecting to the same url no matter what
        redirect_to user_url(@goal.user)
    end

    def edit
        @goal = current_user.goals.find_by(id: params[:id])

        if @goal
            render :edit
        else
            flash[:errors] = ["You cannot update goals created by someone else."]
            redirect_to user_url(current_user.id)
        end
    end

    def update
        @goal = current_user.goals.find_by(id: params[:id])
        # @goal = Goal.find(params[:id])

        if @goal.update(goal_params)
            redirect_to user_url(@goal.user_id)
        else
            flash.now[:errors] = @goal.errors.full_messages
            render :edit
        end
    end

    def destroy
        @goal = current_user.goals.find_by(id: params[:id])

        if @goal 
            # debugger
            @goal.destroy
            redirect_to user_url(current_user.id)
        else
          flash[:errors] = ["You cannot delete someone else's goal."]
          redirect_to users_url
        end
    end
 
    private

    def goal_params
        params.require(:goal).permit(:name, :details, :status)
    end
    
end
